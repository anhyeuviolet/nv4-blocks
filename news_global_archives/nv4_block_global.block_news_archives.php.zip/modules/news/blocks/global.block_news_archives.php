<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate 3/9/2010 23:25
 */

if (! defined('NV_MAINFILE')) {
    die('Stop!!!');
}

if (! nv_function_exists('nv_news_block_news_archives')) {
    function nv_block_config_news_archives($module, $data_block, $lang_block)
    {
        $html = '<tr>';
        $html .= '	<td>' . $lang_block['numrow'] . '</td>';
        $html .= '	<td><input type="text" name="config_numrow" class="form-control w100" size="5" value="' . $data_block['numrow'] . '"/></td>';
        $html .= '</tr>';
        return $html;
    }

    function nv_block_config_news_archives_submit($module, $lang_block)
    {
        global $nv_Request;
        $return = array();
        $return['error'] = array();
        $return['config'] = array();
        $return['config']['numrow'] = $nv_Request->get_int('config_numrow', 'post', 0);
        return $return;
    }

    function nv_news_block_news_archives($block_config)
    {
        global $nv_Cache, $module_array_cat, $module_info, $site_mods, $module_config, $global_config, $db;
        $module = $block_config['module'];

        $numrow = (isset($block_config['numrow'])) ? $block_config['numrow'] : 50;

        $cache_file = NV_LANG_DATA . '__block_news_' . $numrow . '_' . NV_CACHE_PREFIX . '.cache';
        if (($cache = $nv_Cache->getItem($module, $cache_file)) != false) {
            $array_block_news = unserialize($cache);
        } else {
            $array_block_news = array();

            $db->sqlreset()
                ->select("FROM_UNIXTIME(publtime, '%Y') AS year, FROM_UNIXTIME(publtime, '%m') AS month, id, catid, publtime, exptime, title, alias, homeimgthumb, homeimgfile, hometext")
                ->from(NV_PREFIXLANG . '_' . $site_mods[$module]['module_data'] . '_rows')
                ->where('status= 1')
                ->order('publtime DESC')
                ->limit($numrow);
            $result = $db->query($db->sql());
			
			$prevYear = '';
			$prevMonth = '';
			$show_year = '';
			$show_month = '';
			$close_month = '';
			$close_year = '';
			
            while (list($year, $month, $id, $catid, $publtime, $exptime, $title, $alias, $homeimgthumb, $homeimgfile, $hometext) = $result->fetch(3)) {
                $link = NV_BASE_SITEURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module . '&amp;' . NV_OP_VARIABLE . '=' . $module_array_cat[$catid]['alias'] . '/' . $alias . '-' . $id . $global_config['rewrite_exturl'];
				// Year
				if ( $year <> $prevYear ) {
					$show_year = $year;
					if(!empty($prevYear)){
						$close_year = true;
					}
				}
				else{
					$show_year = '';
					$close_year = false;
				}
				// Month
				if ($year <> $prevYear || $month <> $prevMonth) {
					if ($year == $prevYear) {
						$close_month = true;
					}
					$show_month = $month;
				}
				else{
					$show_month = '';
					$close_month = false;
				}
				
				$prevYear = $year;
				$prevMonth = $month;
				
				$array_block_news[] = array(
					'id' => $id,
					'title' => $title,
					'link' => $link,
					'hometext' => $hometext,
					'year' => $year,
					'month' => $month,
					'prevYear' => $prevYear,
					'prevMonth' => $prevMonth,
					'show_year' => $show_year,
					'show_month' => $show_month,
					'close_year' => $close_year,
					'close_month' => $close_month
				);
            }
            $cache = serialize($array_block_news);
            $nv_Cache->setItem($module, $cache_file, $cache);
        }

        if (file_exists(NV_ROOTDIR . '/themes/' . $global_config['module_theme'] . '/modules/news/block_news_archives.tpl')) {
            $block_theme = $global_config['module_theme'];
        } else {
            $block_theme = 'default';
        }
        $xtpl = new XTemplate('block_news_archives.tpl', NV_ROOTDIR . '/themes/' . $block_theme . '/modules/news/');
        $xtpl->assign('NV_BASE_SITEURL', NV_BASE_SITEURL);

        foreach ($array_block_news as $array_news) {
			if( $array_news['close_month'] OR $array_news['close_year'] ){
				$xtpl->parse('main.post.close_month');
			}
			
			if(!empty($array_news['show_month'])){
				$xtpl->assign('show_month', $array_news['show_month']);
				$xtpl->parse('main.post.month');
			}
			
			if( $array_news['close_year'] ){
				$xtpl->parse('main.post.close_year');
			}
			
			if(!empty($array_news['show_year'])){
				$xtpl->assign('show_year', $array_news['show_year']);
				$xtpl->parse('main.post.year');
				$xtpl->parse('main.post.open_month');
			}
				$xtpl->assign('blocknews', $array_news);
				$xtpl->parse('main.post');
			}
        $xtpl->parse('main');
        return $xtpl->text('main');
    }
}

if (defined('NV_SYSTEM')) {
    global $nv_Cache, $site_mods, $module_name, $global_array_cat, $module_array_cat;
    $module = $block_config['module'];
    if (isset($site_mods[$module])) {
        $mod_data = $site_mods[$module]['module_data'];
        if ($module == $module_name) {
            $module_array_cat = $global_array_cat;
            unset($module_array_cat[0]);
        } else {
            $module_array_cat = array();
            $sql = 'SELECT catid, parentid, title, alias, viewcat, subcatid, numlinks, description, status, keywords, groups_view FROM ' . NV_PREFIXLANG . '_' . $mod_data . '_cat ORDER BY sort ASC';
            $list = $nv_Cache->db($sql, 'catid', $module);
            foreach ($list as $l) {
                $module_array_cat[$l['catid']] = $l;
                $module_array_cat[$l['catid']]['link'] = NV_BASE_SITEURL . 'index.php?' . NV_LANG_VARIABLE . '=' . NV_LANG_DATA . '&amp;' . NV_NAME_VARIABLE . '=' . $module . '&amp;' . NV_OP_VARIABLE . '=' . $l['alias'];
            }
        }
        $content = nv_news_block_news_archives($block_config, $mod_data);
    }
}