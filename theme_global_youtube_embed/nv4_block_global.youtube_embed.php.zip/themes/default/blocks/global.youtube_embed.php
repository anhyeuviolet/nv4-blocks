<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Sun, 04 May 2014 12:41:32 GMT
 */

if( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

if( ! nv_function_exists( 'get_youtube_id' ) )
{

	function get_youtube_id($url){
		preg_match("/^(?:http(?:s)?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user)\/))([^\?&\"'>]+)/", $url, $matches);
		return $matches[1];
	}

}
if( ! nv_function_exists( 'AutoParseYoutubeLink' ) )
{
	function AutoParseYoutubeLink($url) {
		$data = array();
		if (strpos ( $url, 'list=' ) !== false) {
			$data['embed'] = preg_replace ( '~(?:http|https|)(?::\/\/|)(?:www.|)(?:youtu\.be\/|youtube\.com(?:\/embed\/|\/v\/|\/watch\?v=|\/ytscreeningroom\?v=|\/feeds\/api\/videos\/|\/user\S*[^\w\-\s]|\S*[^\w\-\s]))([\w\-]{12,})[a-z0-9;:@#?&%=+\/\$_.-]*~i', 'https://www.youtube.com/embed/?list=$1', $url );
			$data['list'] = true;
			return $data;
		}
		$data['embed'] = preg_replace ( '~(?:http|https|)(?::\/\/|)(?:www.|)(?:youtu\.be\/|youtube\.com(?:\/embed\/|\/v\/|\/watch\?v=|\/ytscreeningroom\?v=|\/feeds\/api\/videos\/|\/user\S*[^\w\-\s]|\S*[^\w\-\s]))([\w\-]{11})[a-z0-9;:@#?&%=+\/\$_.-]*~i', 'https://www.youtube.com/embed/$1', $url );
		$data['list'] = false;
		return $data;
	}
}

if( ! nv_function_exists( 'nv_youtube_embed' ) )
{
	function nv_youtube_embed_config( $module, $data_block, $lang_block )
    {
        $html = "";
        $html .= "<tr>";
        $html .= "	<td>" . $lang_block['youtube_link'] . "</td>";
        $html .= "	<td><input placeholder=\"https://www.youtube.com/watch?v=VT1-sitWRtY&list=RDVT1-sitWRtY\" type=\"text\" name=\"config_youtube_link\" size=\"50\" value=\"" . $data_block['youtube_link'] . "\"/></td>";
        $html .= "</tr>";
		
        $html .= "<tr>";
        $html .= "  <td>" . $lang_block['width'] . "</td>";
        $html .= "  <td><input type=\"text\" name=\"config_width\" size=\"5\" value=\"" . $data_block['width'] . "\"/></td>";
        $html .= "</tr>";
		
        $html .= "<tr>";
        $html .= "  <td>" . $lang_block['height'] . "</td>";
        $html .= "  <td><input type=\"text\" name=\"config_height\" size=\"5\" value=\"" . $data_block['height'] . "\"/></td>";
        $html .= "</tr>";
		
        $html .= "<tr>";
        $html .= "  <td>" . $lang_block['border'] . "</td>";
        $html .= "  <td><input type=\"text\" name=\"config_border\" size=\"5\" value=\"" . $data_block['border'] . "\"/></td>";
        $html .= "</tr>";
        
        $html .= "<tr>";
        $html .= "  <td>" . $lang_block['autoplay'] . "</td>";
        $autoplay = ($data_block['autoplay']==true)? 'checked="checked"': '';
        $html .= "  <td><input type=\"checkbox\" name=\"config_autoplay\" value=\"true\" ".$autoplay." \></td>";
        $html .= "</tr>";
		
        $html .= "<tr>";
        $html .= "  <td>" . $lang_block['fullscreen'] . "</td>";
        $fullscreen = ($data_block['fullscreen']==true)? 'checked="checked"': '';
        $html .= "  <td><input type=\"checkbox\" name=\"config_fullscreen\" value=\"true\" ".$fullscreen." \></td>";
        $html .= "</tr>";
		
		return $html;
	}

	function nv_youtube_embed_submit( $module, $lang_block )
	{
		global $nv_Request;
		$return = array();
		$return['error'] = array();
		$return['config']['youtube_link'] = $nv_Request->get_title( 'config_youtube_link', 'post' );
		$return['config']['width'] = $nv_Request->get_int( 'config_width', 'post', 640 );
		$return['config']['height'] = $nv_Request->get_int( 'config_height', 'post', 480 );
		$return['config']['border'] = $nv_Request->get_int( 'config_border', 'post', 0 );
		$return['config']['autoplay'] = $nv_Request->get_int( 'config_autoplay', 'post', 0 );
		$return['config']['fullscreen'] = $nv_Request->get_int( 'config_fullscreen', 'post' );
		return $return;
	}

	function nv_youtube_embed( $block_config )
	{
		global $global_config, $site_mods, $blockID;

		if( file_exists( NV_ROOTDIR . '/themes/' . $global_config['module_theme'] . '/blocks/global.youtube_embed.tpl' ) )
		{
			$block_theme = $global_config['module_theme'];
		}
		elseif( file_exists( NV_ROOTDIR . '/themes/' . $global_config['site_theme'] . '/blocks/global.youtube_embed.tpl' ) )
		{
			$block_theme = $global_config['site_theme'];
		}
		else
		{
			$block_theme = 'default';
		}

		$xtpl = new XTemplate( 'global.youtube_embed.tpl', NV_ROOTDIR . '/themes/' . $block_theme . '/blocks' );
		$xtpl->assign( 'NV_BASE_SITEURL', NV_BASE_SITEURL );
		$xtpl->assign( 'BLOCK_THEME', $block_theme );
		$xtpl->assign( 'BLOCKID', $blockID );
		$block_config['youtube_embed'] = AutoParseYoutubeLink($block_config['youtube_link'])['embed'];
		$xtpl->assign( 'YOUTUBE', $block_config );

		if( $block_config['autoplay'] and $block_config['youtube_embed']['list'] == false )
		{
			$xtpl->parse( 'main.autoplay' );
		}
		if( ! empty( $block_config['youtube_link'] ) )
		{
			$xtpl->parse( 'main.youtube_link' );
		}
		if( ! empty( $block_config['width'] ) )
		{
			$xtpl->parse( 'main.width' );
		}
		if( ! empty( $block_config['height'] ) )
		{
			$xtpl->parse( 'main.height' );
		}
		if( $block_config['fullscreen'] )
		{
			$xtpl->parse( 'main.fullscreen' );
		}
		if( ! empty( $block_config['border'] ) )
		{
			$xtpl->parse( 'main.border' );
		}
		$xtpl->parse( 'main' );
		return $xtpl->text( 'main' );
	}
}

if( defined( 'NV_SYSTEM' ) )
{
	$content = nv_youtube_embed( $block_config );
}